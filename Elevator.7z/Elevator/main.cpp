#include <curses.h>
#include <time.h>
#include <iostream>
#include <windows.h>

using namespace std;

const int randomFloor[11]= {2,3,4,5,6,7,8,9,10,11,12};
const int StayOrLeave[5]= {0,0,0,0,1};

//*****���ɶ�:1��*****//


class  elevator
{
private:
    int ID;
    int NumOfPeople=0;
    bool UpOrDown;//0=down 1=up
    int NowFloor=1;
    int NextFloor;
    int PeopleInElevator[10]= {0};
    int StayTime=2;
    int InOutNum=0;//The number of people who get into or get out the elevator
public:
    void setUpOrDown(bool updown)
    {
        UpOrDown=updown;
    }
    void setNumOfPeople(int peoplenum)
    {
        NumOfPeople=peoplenum;
    }
    void setNowFloor(int floor)
    {
        NowFloor=floor;
    }
    void setNextFloor(int floor)
    {
        NextFloor=floor;
    }
    int getID()
    {
        return ID;
    }
    int getNumOfPeople()
    {
        return NumOfPeople;
    }
    int getNowFloor()
    {
        return NowFloor;
    }
    int getNextFloor()
    {
        return NextFloor;
    }
    bool getUpOrDown()
    {
        return UpOrDown;
    }
    void setPeopleInElevator(int floor)
    {
        for(int i=0; i<10; i++)
        {
            if(PeopleInElevator[i]==0)
            {
                PeopleInElevator[i]=floor;
                NumOfPeople++;
                InOutNum++;
                break;
            }
        }
    }
    void releasePeopleInElevator()
    {
        int floor=NowFloor;
        for(int i=0;i<10; i++)
        {
            if(PeopleInElevator[i]==floor)
            {
                PeopleInElevator[i]=0;
                NumOfPeople--;
                InOutNum++;
            }
        }
    }
    void setStayTime()
    {
        int time=InOutNum*0.7;
        if(time>2)
        {
            StayTime=time;
        }
    }
    int getStayTime()
    {
        return StayTime;
    }
    void resetStayTime()
    {
        StayTime=2;
        InOutNum=0;
    }
};


class people
{
    int **arr;
    int numberofpeople;
public:
    people();
    void generate(const int n);         //�ͦ� n �ӤH
    void deleteID(const int ID);          //�R�� �s��ID ���H
    int getNumberofpeople();        //��o�ثe�`�H��
    void setID();
    void setCurrentfloor(const int &ID,const int floor);
    void setDestination(const int &ID,const int floor);
    void setStaytime(const int &ID,const int t);
    void setState(const int &ID,const bool state);                           //�]�w�U�Ӫ��A:0���}1���d��
    void setPosition(const int &ID,const int p);                     //�]�w�ثe��m:1�Ӽh2���q��3�q�褺
    void setElevator(const int &ID,const int eleID);
    int getID(const int i);
    int getCurrentfloor(const int ID);
    int getDestination(const int ID);
    int getStaytime(const int ID);
    int getState(const int ID);
    int getPosition(const int ID);
    int getElevator(const int ID);
};

people::people()
{
    int **arr=new int *[150];
    for(int i=0; i<150; i++)
    {
        arr[i]=new int [7]();                 //�x�s"ID"�B"���e�Ӽh"�B"�ؼмӼh"�B"�ݦh�["�B"�ثe��m"�B"�U�Ӫ��A(�~�򰱯d�ηǳ����})"�B"�ϥέ��x�q��"
    }
    numberofpeople=0;
}
void people::generate(const int n)
{
    for(int i=0; i<n; i++)
    {
        int n=rand()%11;
        setID();
        setCurrentfloor(getID(numberofpeople),1);
        setDestination(getID(numberofpeople),randomFloor[n]);
        setStaytime(getID(numberofpeople),rand()%61+20);
        setState(getID(numberofpeople),0);
        numberofpeople++;
    }
}
void people::deleteID(const int ID)
{
    for(int i=ID; i<149; i++)
    {
        for(int j=0; j<7; j++)
        {
            arr[i][j]=arr[i+1][j];
        }
    }
    for(int i=0; i<7; i++)
    {
        arr[150][i]=0;
    }
    numberofpeople--;
}
int people::getNumberofpeople()
{
    return numberofpeople;
}
void people::setID()
{
    arr[numberofpeople][0]=numberofpeople+1;
}
void people::setCurrentfloor(const int &ID,const int floor)
{
    arr[ID-1][1]=floor;
}
void people::setDestination(const int &ID,const int floor)
{
    arr[ID-1][2]=floor;
}
void people::setStaytime(const int &ID,const int t)
{
    arr[ID-1][3]=t;
}
void people::setPosition(const int &ID,const int p)
{
    arr[ID-1][4]=p;
}
void people::setState(const int &ID,const bool state)
{
    arr[ID-1][5]=state;
}
void people::setElevator(const int &ID,const int eleID)
{
    arr[ID-1][6]=eleID;
}
int people::getID(const int i)
{
    return arr[i][0];
}
int people::getCurrentfloor(const int ID)
{
    return arr[ID-1][1];
}
int people::getDestination(const int ID)
{
    return arr[ID-1][2];
}
int people::getStaytime(const int ID)
{
    return arr[ID-1][3];
}
int people::getPosition(const int ID)
{
    return arr[ID-1][4];
}
int people::getState(const int ID)
{
    return arr[ID-1][5];
}



int main()
{

}


void people::Countdown()
{
    for(int i=0; i<150; i++)
    {
        if(getState(i+1)==1)    //�p�G���d��
        {
            if(getStaytime(i+1)==0)
            {
                Displacement(i+1);      //����
            }
            else
                setStaytime(i+1,getStaytime(i+1)-1);        //-1���ɶ�
        }
        else if(getState(i+1)==2)       //�p�G�b���q��
        {

            if(getDestination(i+1)-getCurrentfloor(i+1)>0)
            {
                1.
            }
            else if(getDestination(i+1)-getCurrentfloor(i+1)<0)
            {

            }
        }
        else if(getState(i+1)==3)       //�p�G�b�q�褺
        {

        }
    }
}
void people::Displacement(const int &ID)
{
    setPosition(ID,2);  //�N��m�]��2:���q��
    int n=rand()%5;
    setState(ID,StayOrLeave[n]);    //�M�w�U�Ӫ��A (80%)0:���} (20%)1:���L�Ӽh
    if(getState(ID)==0)
    {
        setDestination(ID,1);
    }
    else if(getState(ID)==1)
    {
        int f=rand()%11;
        int t=rand()%61+20;
        setDestination(ID,randomFloor[f]);
        setStaytime(ID,t);
    }
}

